# Popp To The Moon BOT

## Table Of Contents
- [Popp To The Moon BOT](#popp-to-the-moon-bot)
  - [POPP Social Summer Airdrop](#popp-social-summer-airdrop)
  - [POPP To The Moon](#popp-to-the-moon)
  - [Bot Feature](#bot-feature)
  - [Prerequisite](#prerequisite)
  - [Setup \& Configure BOT](#setup--configure-bot)
  - [Setup Session](#setup-session)
  - [Note](#note)
  - [CONTRIBUTE](#contribute)
  - [SUPPORT](#support)

## POPP Social Summer Airdrop
New Airdrops: POPP SOCIAL SUMMER 
🏷 Reward Total : $20,000,000 USDT & PoPP $SD 
✔ Mint a TBA, join PoPP SocialSummer to win at least  $20 worth of rewards, and up to 1 BTC in September! 

➡️ Mint TBA  :  https://socialsummer.ai/invite?code=ZGUNMW
👉 Use code: ZGUNMW (Earn extra bonus)

- Mint Price : 0.003 ETH Taiko ( First 10K Minter ) 0.006 Now
- You Can Use New Wallet
- Bridge ETH L2 to Taiko at Least 0.006 ETH
- Mint TBA NFT
- Earn USDT, NFTs, tokens, whitelists, airdrops, and over 40K $SD by completing tasks.
   
➡️ Bridge Via : gas.zip or owlto

📖 As TBA holders, you will get PoPP Token airdrop worth millions directly after TGE, and receive extra bonuses from 
over 200 global projects for the SocialSummer campaign! 

🗓 Date : July 8 - Sep 18. 

## POPP To The Moon
PoPP To The Moon Task Mission is Live! Join Social Summer and Claim $SD to Get PoPP Tokens
🏷 Reward Total: PoPP $SD & $20,000,000 USDT Prize Pool
➡️ Go to : https://t.me/PoPPtothemoon_bot/moon?startapp=5703822759

- Login
- Launch Rocket
- Free to Farm SDs
- Use your free coupons for the lucky draw
- Free to Win $ETH Box
- Finish the task mission to get more PoPP SD

Popp to the moon is Mining game on Telegram that allow you to earn more SD.

## Bot Feature

- Auto Mining
- Auto Claim Mining Reward
- Auto Check In
- Auto Explore Planet
- Auto Complete SOME missoin

## Prerequisite

- Git
- Node JS
- TELEGRAM_APP_ID & TELEGRAM_APP_HASH Get it from [Here](https://my.telegram.org/auth?to=apps)
- Popp Account , Create [Here](🔥Hey! To The Moon! 🚀🌕 My invite link: https://t.me/PoPPtothemoon_bot/moon?startapp=5703822759) ,join and claim join reward, also don't forget to complete mandatory missions some completable mission.

## Setup & Configure BOT

1. clone project repo `git clone https://github.com/Widiskel/popp-to-the-moon-bot.git` and cd to project dir `cd popp-to-the-moon-bot`
2. run `npm install`
3. run `npm i telegram@2.22.2`
4. run `cp src/config/config_tmp.js src/config/config.js`
   To configure the app, open `src/config.js` and add your telegram app id and hash there
5. run `mkdir sessions`
6. to start the app run `npm run start`

## Setup Session

1. run bot `npm run start`
2. choose option 1 create session
3. enter session name
4. enter your phone number starting with countrycode ex : `+628xxxxxxxx`
5. after creating sessions, choose 3 start bot
6. if something wrong with your sessions, reset sessions first, to cancel running bot press `ctrl+c` twice, and start again [from No 1.](#setup-session).

## Note

This bot using telegram sessions. if you ever use one of my bot that use telegram sessions, you can just copy the sessions folder to this bot. Also for the telegram APP ID and Hash you can use it on another bot.

if you got error `Invalid ConstructorId` try to run this ```npm i telegram@2.22.2```

## CONTRIBUTE

Feel free to fork and contribute adding more feature thanks.

## SUPPORT

want to support me for creating another bot ?
**star** my repo or buy me a coffee on

EVM : `0x0fd08d2d42ff086bf8c6d057d02d802bf217559a`

SOLANA : `3tE3Hs7P2wuRyVxyMD7JSf8JTAmEekdNsQWqAnayE1CN`
